For now, I�ve attached the Notepad++ files and the Python script that generated them, along with a screenshot and the bleapi.xml file I used. Installation is like so:

1.	Open Notepad++
2.	In the 'View' menu, click 'User-Defined Dialogue...'
3.	Click 'Import...' and select the 'userDefineLang_BGScript.xml' file
4.	Copy 'BGScript.xml' file to '<NPP-Install-Dir>\plugins\APIs'
5.	In the 'Settings' menu, click 'Preferences...', then 'Backup/Autocompletion'
6.	Enable Auto-Completion options as desired

Two things to note: if you already have a BGScript user-defined language in Notepad++, you MUST remove it first. Also, the 'APIs' folder is typically found at 'C:\Program Files\Notepad++\plugins\APIs'.
